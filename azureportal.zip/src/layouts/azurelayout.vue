<template>
<div>
<ul>
  <li><a >MudId</a></li>
  <li><a >Help</a></li>
  <li><a >Projects</a></li>
  <li class="logo"><img alt="Gsk logo" class="img-logo" src="../assets/logo.png"> 
  <span style="vertical-align:middle;font-size:12px">AZURE PORTAL</span></li>
</ul>
<router-view></router-view>
<div class="footer">
  <div class="footer--left">
          <img class="footer__logo" src="@/assets/gsk-logo.svg" alt="GSK Logo" />
          <span  style="margin-left:30px">© 2019 GlaxoSmithKline. All rights reserved.</span>
          <span  style="margin-left:700px">SHARED RESPONSIBILITIES AGREEMENT</span>
    </div>
</div>
</div>
</template>

<script lang="ts">
import Vue from 'vue'
export default Vue.extend({
   
})
</script>

<style scoped>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #fff;
  box-shadow: 2px 1px #DCDCDC;
}

li {
  float: right;
}

.img-logo{
     height: 60px;
    width: 60px; 
}

img {
     vertical-align:middle;
}
span {
     vertical-align:middle;
}

.logo{
     float: left;
     margin-left: 20px;
}

li a {
  margin-top: 3px;
  display: block;
  color: #757575  ;
  text-align: center;
  padding: 20px 16px;
  text-decoration: none;
  height: 60px;
  font-weight: bold;
}

li a:hover:not(.active) {
  border-bottom: 4px solid #32877c;
  padding-bottom: 2px;
}

.active {
  background-color: #4CAF50;
}

.footer {
  position: fixed;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 50px;
  background-color: white;
  border-top: 0.5px solid #DCDCDC;
  box-shadow: 1px 1px #DCDCDC;
}

.footer--left{
  text-align: left;
  font-size: 13px;
  margin-top: 10px;
  margin-left: 50px;
}
</style>