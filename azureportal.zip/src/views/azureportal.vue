<template>
    <div>
        <div class="max-width"><br>
            <h1>Azure Portal</h1>
            <h4>Welcome to GSK Azure Portal, This is where you can explore across environments.</h4>
            <input type="text" placeholder="Search Azure Console">
        </div>
        <ul class="nav">
            <li :class="{active:msg==='Home'}"><router-link  :to="{path:'home', query: { page: 'Home' }}">Home</router-link ></li>
            <li :class="{active:msg==='About'}"><router-link  :to="{path:'about', query: { page: 'About' }}">About</router-link></li>
            <li :class="{active:msg==='Work'}"><router-link  :to="{path:'work', query: { page: 'Work' }}">Work</router-link ></li>
            <li :class="{active:msg==='Clients'}"><router-link  :to="{path:'clients', query: { page: 'Clients' }}">Clients</router-link ></li>
            <li :class="{active:msg==='Contact'}"><router-link  :to="{path:'contact', query: { page: 'Contact' }}">Contact</router-link ></li>
        </ul>
        <div class="newcomponent">
            <h3><img class="footer__logo" src="@/assets/rpa.svg" alt="GSK Logo" />
            <span >Viewing the {{msg}} tab</span>
            </h3>
        </div>
    </div>
</template>

<script lang="ts">
import {Component, Vue, Watch} from 'vue-property-decorator';

@Component
export default class HelloWorld extends Vue {
    private msg = ""
    public constructor() {
      super();
      console.log("came")
    }
   @Watch('$route', { immediate: true, deep: true })
   onUrlChange(newVal: any) {
     if(newVal.query.page===undefined)
        this.msg='Home';
     else
        this.msg=newVal.query.page;
     //alert(newVal.query.page)
    }
  }

</script>

<style scoped>

.max-width{
    width:100%;
    height:250px;
    margin-top: 2px;
    background-color: #32877c;
}

h1{
   margin: 20px;
   color: #ffff;
   font-weight: 700;
   font-size: 45px;
}

h4{
    margin:20px;
    color:white;
    font-weight: 300;
}

input{
    margin:20px;
    width: 30%;
    height: 15%;
}

.nav{
    border:1px solid #ccc;
    border-width:1px 0;
    list-style-type:none;
    margin:0;
    padding:0;
    box-shadow: 0.5px 0px #DCDCDC;
}
.nav li{
    display:inline;
    padding:15px 10px 6px 10px;
}
li a{ 
    display:inline-block;
    text-decoration: none;
    list-style-type:none;
    color: #212121 ;
    padding:15px 20px 6px 20px;
}

li:hover{
    background-color: #E5F0EE;
}

.active{
    border-bottom: 2px solid #32877c;
    background-color: #B2D2CE;
}

.newcomponent{
    margin:60px 40px 0 40px;
}

img {
     vertical-align:middle;
     fill: green;
}
span {
     vertical-align:middle;
     margin-left: 20px;
}
</style>